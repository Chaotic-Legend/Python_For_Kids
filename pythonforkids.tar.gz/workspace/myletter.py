spaces = ' ' * 25 
print('%s 12 Butts Wynd' % spaces)
print('%s Twinklebottom Heath' % spaces)
print('%s West Snoring' % spaces)
print()
print()
print('Dear Sir')
print()
print('I wish to report that tiles are missing from the')
print('outside toilet roof.')
print()
print('Regrads')
print('Malcom Dithering')

#See Mr.Maxim about this!